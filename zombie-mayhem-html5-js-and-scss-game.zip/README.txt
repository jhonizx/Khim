A Pen created at CodePen.io. You can find this one at http://codepen.io/eliortabeka/pen/RoNgzR.

 #####Kill or be eaten in the Zombie Mayhem